    <!-- Footer -->
<footer class="footer bg-dark">
  <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Health Management Info System Inventory <?php echo date('Y'); ?></p>
      </div>
  </footer>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script type="text/javascript" charset="utf8" src="vendor/DataTables/datatables.js"></script>
	<script type="text/javascript" charset="utf8" src="vendor/DataTables/sumsum.js"></script>
	<script src="vendor/chosen/chosen.jquery.min.js"></script>
	<link rel="stylesheet" href="vendor/chosen/chosen.css" />
	<script src="vendor/datepicker164/js/bootstrap-datepicker.min.js"></script>
	<script src="vendor/bootbox/bootbox.min.js"></script>
	<script src="assets/js/scripts.js"></script>
	<script src="assets/js/login.js"></script>