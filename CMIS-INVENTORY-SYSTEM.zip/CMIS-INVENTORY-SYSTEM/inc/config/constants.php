<?php
	
	define('ROOT_URL', 'http://localhost/inventory-management-system/');
	define('DSN', 'mysql:host=localhost;dbname=shop_inventory');
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASSWORD', '');
	define('DB_NAME', 'shop_inventory');
?>