<div class="navbar navbar-default navbar-fixed-bottom" style="background-color: white !important; background-image: none; padding: .25em 0;">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-5" style="height: 100%;">
                    <div style="display: flex; flex-direction: row; align-items: flex-start; justify-content: space-between; flex-wrap: nowrap; flex-flow: row; height: 3em;">
                        <div style="height: 100%; text-align: left; flex-basis: 25%"><img style="height: 100%;" alt="Ministry of Health logo" src="Images/MoH-square.png" /></div>
                        <div style="height: 100%;"><img style="height: 100%;" alt="USAID logo" src="Images/USAID-square.png" /></div>
                        <div style="height: 100%;"><img style="height: 100%;" alt="PEPFAR logo" src="Images/PEPFAR-square.png" /></div>
                        <div style="height: 100%;"><img style="height: 100%;" alt="HMIS logo" src="Images/hmis-square.png" /></div>
                        <div style="height: 100%;"><img style="height: 100%;" alt="FEI logo" src="Images/fei-square.png" /></div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-5">
                </div>
                <div class="col-md-4  col-sm-5 pull-right">
				<span style="font-size:10px;" class="text-primary">Copyright &copy; Health Management Information System</span>
                        <br />

                </div>
            </div>
        </div>

