<div class="container"> 
<nav class="navbar navbar-inverse" style="margin-top:-45px;">
    <div class="container-fluid" style="width:100%;">
     <div class="banner">
<img src="img/hmis-square.png" width="120" height="90" style="position:absolute;margin-top:-2px;">
<div style="color:yellow;margin-left:200px;margin-bottom:50px;margin-top:20px;font-size:30px;font-family:Bodoni MT Black;">HMIS INVENTORY MANAGEMENT SYSTEM</div>
      </div> 
     </div>
    </nav>
    </div>