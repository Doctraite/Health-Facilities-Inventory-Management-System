<?php
	require_once('../../inc/config/constants.php');
	require_once('../../inc/config/db.php');
	if(isset($_POST['VendorID'])){
		
		$saleID = htmlentities($_POST['VendorName']);
		
		$saleDetailsSql = 'SELECT vendorName FROM vendor WHERE VendorName = :VendorName';
		$saleDetailsStatement = $conn->prepare($saleDetailsSql);
		$saleDetailsStatement->execute(['VendorName' => $saleID]);
		if($saleDetailsStatement->rowCount() > 0) {
			$row = $saleDetailsStatement->fetch(PDO::FETCH_ASSOC);
			echo json_encode($row);
		}
		$saleDetailsStatement->closeCursor();
	}
?>