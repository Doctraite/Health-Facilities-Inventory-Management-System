<?php
	require_once('../../inc/config/constants.php');
	require_once('../../inc/config/db.php');
	
	$uPrice = 0;
	$qty = 0;
	$totalPrice = 0;
	
	$saleDetailsSearchSql = 'SELECT * FROM deployment';
	$saleDetailsSearchStatement = $conn->prepare($saleDetailsSearchSql);
	$saleDetailsSearchStatement->execute();

	$output = '<table id="saleDetailsTable" class="table table-sm table-striped table-bordered table-hover" style="width:100%">
				<thead>
					<tr>
						<th>Facility Name</th>
						<th>Building Name</th>
						<th>Room Type</th>
						<th>Equipment Serial Number</th>
						<th>Equipment Name</th>
						<th>CMIS Personnel</th>
						<th>Deployment Date</th>
						<th>Facility Contact Person</th>
					</tr>
				</thead>
				<tbody>';
	
	// Create table rows from the selected data
	while($row = $saleDetailsSearchStatement->fetch(PDO::FETCH_ASSOC)){
			
		$output .= '<tr>' .
						'<td>' . $row['facility_name'] . '</td>' .
						'<td>' . $row['building'] . '</td>' .
						'<td>' . $row['room'] . '</td>' .
						'<td>' . $row['itemNumber'] . '</td>' .
						'<td>' . $row['itemName'] . '</td>' .
						'<td>' . $row['vendorName'] . '</td>' .
						'<td>' . $row['saleDate'] . '</td>' .
						'<td>' . $row['person'] . '</td>' .
					'</tr>';
	}
	
	$saleDetailsSearchStatement->closeCursor();
	
	$output .= '</tbody>
					<tfoot>
						<tr>
						<th>Facility Name</th>
						<th>Building Name</th>
						<th>Room Type</th>
						<th>Equipment Serial Number</th>
						<th>Equipment Name</th>
						<th>CMIS Personnel</th>
						<th>Deployment Date</th>
						<th>Facility Contact Person</th>
						</tr>
					</tfoot>
				</table>';
	echo $output;
?>


