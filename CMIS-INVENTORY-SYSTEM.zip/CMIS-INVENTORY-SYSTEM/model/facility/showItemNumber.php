<?php
	require_once('../../inc/config/constants.php');
	require_once('../../inc/config/db.php');
	
	if(isset($_POST['textBoxValue'])){
		$output = '';
		$serialNumberString = '%' . htmlentities($_POST['textBoxValue']) . '%';
		$sql = 'SELECT * FROM facility WHERE facility_code LIKE ?';
		$stmt = $conn->prepare($sql);
		$stmt->execute([$serialNumberString]);
		if($stmt->rowCount() > 0){
			$output = '<ul class="list-unstyled suggestionsList" id="itemDetailsItemNumberSuggestionsList">';
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$output .= '<li>' . $row['facility_code'] . '</li>';
			}
			echo '</ul>';
		} else {
			$output = '';
		}
		$stmt->closeCursor();
		echo $output;
	}
?>