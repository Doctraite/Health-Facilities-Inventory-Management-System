<?php
	$itemDetailsSql = 'SELECT facility_name FROM facility';
	$itemDetailsStatement = $conn->prepare($itemDetailsSql);
	$itemDetailsStatement->execute();
	
	if($itemDetailsStatement->rowCount() > 0) {
		while($row = $itemDetailsStatement->fetch(PDO::FETCH_ASSOC)) {
			echo '<option>' . $row['facility_name'] . '</option>';
		}
	}
	$itemDetailsStatement->closeCursor();
?>