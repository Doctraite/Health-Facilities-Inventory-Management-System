<?php
	require_once('../../inc/config/constants.php');
	require_once('../../inc/config/db.php');
	

	if(isset($_POST['customerDetailsCustomerFullName'])) {
		
		//$facilityNumber = htmlentities($_POST['facilityDetailsItemNumber']);
		$facilityID = htmlentities($_POST['customerDetailsCustomerFullName']);
		$facilityName = htmlentities($_POST['customerDetailsCustomerCity']);
		$facilityType = htmlentities($_POST['customerDetailsCustomerDistrict']);
	
		
		if(!empty($facilityID)){
			
			$facilityID = filter_var($facilityID, FILTER_SANITIZE_STRING);
			
			$updateItemDetailsSql = 'UPDATE facility SET facility_code = :facility_code, facility_name = :facility_name, facility_type = :facility_type,  WHERE facility_ID = :facility_ID';
			$updateItemDetailsStatement = $conn->prepare($updateItemDetailsSql);
			$updateItemDetailsStatement->execute(['facility_name' => $facilityName, 'facility_type' => $facilityType, 'facility_code' => $facilityID]);
			$updateItemInPurchaseTableSstatement = $conn->prepare($updateItemInPurchaseTableSql);
			$updateItemInPurchaseTableSstatement->execute(['facility_name' => $facilityName, 'facility_code' => $facilityID]);
			$successAlert = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Facility details updated.</div>';
			$data = ['alertMessage' => $successAlert, 'newStock' => $newStock];
			echo json_encode($data);
			exit();
			
		} else {
			$errorAlert = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Please enter all fields marked with a (*)</div>';
			$data = ['alertMessage' => $errorAlert];
			echo json_encode($data);
			exit();
		}
	}
?>