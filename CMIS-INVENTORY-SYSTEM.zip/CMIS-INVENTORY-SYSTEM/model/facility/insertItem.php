<?php
    error_reporting(0);
	require_once('../../inc/config/constants.php');
	require_once('../../inc/config/db.php');
	
	
	if(isset($_POST['facilityDetailsItemNumber'])){
		
		//$facilityNumber = htmlentities($_POST['facilityDetailsItemNumber']);
		$facilityID = htmlentities($_POST['customerDetailsCustomerFullName']);
		$facilityName = htmlentities($_POST['customerDetailsCustomerCity']);
		$facilityType = htmlentities($_POST['customerDetailsfacility']);
		
		if(!empty($facilityID) && !empty($facilityName) && !empty($facilityType)){
			$facilityID= filter_var($facilityID, FILTER_SANITIZE_STRING);

			$stockSql = 'SELECT facility_code FROM facility WHERE facility_code=:facility_code';
			$stockStatement = $conn->prepare($stockSql);
			$stockStatement->execute(['facility_code' => $facilityID]);
			if($stockStatement->rowCount() > 0){
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Facility already exists in our system. Please try adding another facility.</div>';
				exit();
			} else {
			
				$SelectFacility = 'SELECT * FROM facility WHERE facility_code = ?';
			    $insertItemStatement = $conn->prepare($SelectFacility);
				$insertItemSql = 'INSERT INTO facility(facility_code, facility_name, facility_type) VALUES(:facility_code, :facility_name, :facility_type)';
				$insertItemStatement = $conn->prepare($insertItemSql);
				$insertItemStatement->execute(['facility_code' => $facilityID, 'facility_name' => $facilityName, 'facility_type' => $facilityType]);
				echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Facility added to database.</div>';
				exit();
			
			}
		} else {
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Please enter all fields marked with a (*)</div>';
			exit();
		}
	}

?>