<?php
	require_once('../../inc/config/constants.php');
	require_once('../../inc/config/db.php');
	
	$serialNumber = htmlentities($_POST['customerDetailsCustomerFullName']);

	
	if(isset($_POST['customerDetailsCustomerFullName'])){
		if(!empty($serialNumber)){
			$serialNumber = filter_var($serialNumber, FILTER_SANITIZE_STRING);
			$itemSql = 'SELECT * FROM facility WHERE facility_code=:facility_code';
			$itemStatement = $conn->prepare($itemSql);
			$itemStatement->execute(['facility_code' => $serialNumber]);
			
			if($itemStatement->rowCount() > 0){
				$deleteItemSql = 'DELETE * FROM facility WHERE facility_code=:facility_code';
				$deleteItemStatement = $conn->prepare($deleteItemSql);
				$deleteItemStatement->execute(['facility_code' => $serialNumber]);

				echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Facility deleted.</div>';
				exit();
				
			} else {
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Facility does not exist our system. Therefore, can\'t delete.</div>';
				exit();
			}
		} else {
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Please enter the facility number</div>';
			exit();
		}
	}
?>