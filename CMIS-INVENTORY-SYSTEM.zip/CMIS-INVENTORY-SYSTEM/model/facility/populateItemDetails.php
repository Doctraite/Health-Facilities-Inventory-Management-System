<?php
	require_once('../../inc/config/constants.php');
	require_once('../../inc/config/db.php');
	if(isset($_POST['facility_code'])){
		
		$serialNumber = htmlentities($_POST['facility_code']);
		$itemDetailsSql = 'SELECT * FROM facility WHERE facility_code = :facility_code';
		$itemDetailsStatement = $conn->prepare($itemDetailsSql);
		$itemDetailsStatement->execute(['facility_code' => $serialNumber]);
		if($itemDetailsStatement->rowCount() > 0) {
			$row = $itemDetailsStatement->fetch(PDO::FETCH_ASSOC);
			echo json_encode($row);
		}
		$itemDetailsStatement->closeCursor();
	}
?>