<?php
	require_once('../../inc/config/constants.php');
	require_once('../../inc/config/db.php');
	
	$serialNumber = htmlentities($_POST['itemDetailsItemNumber']);
	
	if(isset($_POST['itemDetailsItemNumber'])){
		if(!empty($serialNumber)){
			$serialNumber = filter_var($serialNumber, FILTER_SANITIZE_STRING);
			$itemSql = 'SELECT itemNumber FROM item WHERE itemNumber=:itemNumber';
			$itemStatement = $conn->prepare($itemSql);
			$itemStatement->execute(['itemNumber' => $serialNumber]);
			
			if($itemStatement->rowCount() > 0){
				$deleteItemSql = 'DELETE FROM item WHERE itemNumber=:itemNumber';
				$deleteItemStatement = $conn->prepare($deleteItemSql);
				$deleteItemStatement->execute(['itemNumber' => $serialNumber]);

				echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Equipment deleted.</div>';
				exit();
				
			} else {
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Equipment does not exist our system. Therefore, can\'t delete.</div>';
				exit();
			}
		} else {
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Please enter the equipment number</div>';
			exit();
		}
	}
?>