<?php
	require_once('../../inc/config/constants.php');
	require_once('../../inc/config/db.php');
	
	$initialStock = 0;
	$baseImageFolder = '../../data/item_images/';
	$itemImageFolder = '';
	
	if(isset($_POST['itemDetailsItemNumber'])){
		
		$serialNumber = htmlentities($_POST['itemDetailsItemNumber']);
		$itemName = htmlentities($_POST['itemDetailsItemName']);
		$discount = htmlentities($_POST['itemDetailsDiscount']);
		$quantity = htmlentities($_POST['itemDetailsQuantity']);
		$status = htmlentities($_POST['itemDetailsStatus']);
		$description = htmlentities($_POST['itemDetailsDescription']);
		
		if(!empty($serialNumber) && !empty($itemName)){
			$serialNumber = filter_var($serialNumber, FILTER_SANITIZE_STRING);
			$itemImageFolder = $baseImageFolder . $serialNumber;
			if(is_dir($itemImageFolder)){
			} else {
				mkdir($itemImageFolder);
			}
			
			$stockSql = 'SELECT stock FROM item WHERE itemNumber=:itemNumber';
			$stockStatement = $conn->prepare($stockSql);
			$stockStatement->execute(['itemNumber' => $serialNumber]);
			if($stockStatement->rowCount() > 0){
				echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Equipment already exists in our system. Please click the <strong>Update</strong> button to update the details. Or use a different Item Number.</div>';
				exit();
			} else {
				$insertItemSql = 'INSERT INTO item(itemNumber, itemName, cmis_code, stock, status, description) VALUES(:itemNumber, :itemName, :cmis_code, :stock, :status, :description)';
				$insertItemStatement = $conn->prepare($insertItemSql);
				$insertItemStatement->execute(['itemNumber' => $serialNumber, 'itemName' => $itemName, 'cmis_code' => $discount, 'stock' => $quantity, 'status' => $status, 'description' => $description]);
				echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Equipment added to database.</div>';
				exit();
			}

		} else {
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">&times;</button>Please enter all fields marked with a (*)</div>';
			exit();
		}
	}
?>