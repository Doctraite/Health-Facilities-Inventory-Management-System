<div class="container"> 
<nav class="navbar navbar-inverse" style="margin-top:5px;">
    <div class="container-fluid">
     <div class="banner">
<img src="img/hmis-square.png" width="120" height="90" style="position:absolute;margin-top:-10px;">
<div style="color:black;margin-left:250px;margin-bottom:50px;margin-top:20px;font-size:30px;font-family:Bodoni MT Black;">INVENTORY MANAGEMENT SYSTEM</div>
      </div> 
     </div>
    </nav>
</div>